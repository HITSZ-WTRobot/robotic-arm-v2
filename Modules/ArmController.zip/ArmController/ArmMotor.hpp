#pragma once

#include "DM.hpp"
#include "dji.hpp"

namespace modules {
namespace arm {

class ArmMotor {
public:
  enum class MotorType { DJI, DM };

  struct Config {
    MotorType type;

    motors::DJIMotor *dji_motor = nullptr;
    motors::DMMotor *dm_motor = nullptr;
    // MIT Parameters (Default)
    float kp = 0.0f;
    float kd = 0.0f;
    float ki = 0.0f;
    float i_limit = 0.0f;

    // Mechanical
    float reduction_ratio =
        1.0f; // Reduction ratio if needed on TOP of motor driver
    float torque_to_iq = 1.0f; // Conversion factor for Current/Torque
  };

  explicit ArmMotor(const Config &cfg);

  void update(float dt);

  void setTarget(float pos, float vel = 0.0f, float torque_ff = 0.0f);

  void setEnabled(bool enable);

  // Set MIT params dynamically
  void setMitParams(float kp, float kd, float ki, float i_limit);

  float getAngle() const;
  float getVelocity() const;

private:
  Config cfg_;

  bool enabled_ = false;

  // Command state
  float target_pos_ = 0.0f;
  float target_vel_ = 0.0f;
  float target_tff_ = 0.0f;

  // Integral
  float integral_err_ = 0.0f;
};

} // namespace arm
} // namespace modules
