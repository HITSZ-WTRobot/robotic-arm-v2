#pragma once

#include "ArmMotor.hpp"

namespace modules {
namespace arm {

class Controller {
public:
  struct Config {
    float l1, l2, l3;    // Link lengths
    float lc1, lc2, lc3; // CoM distances
    float m1, m2, m3;    // Masses
    float g;

    // Reduction
    float reduction_1, reduction_2, reduction_3;

    // Offsets
    float offset_1, offset_2, offset_3;

    // Constraints
    float q1_min = -180, q1_max = 180;
    float q2_min = -180, q2_max = 180;
    float q3_min = -180, q3_max = 180;
  };

  Controller(ArmMotor &m1, ArmMotor &m2, ArmMotor &m3, const Config &cfg);

  void init();
  void update(float dt);

  // Inverse Kinematics
  bool setTargetPosition(float x, float y, float z, float pitch);

  // Direct Joint Control
  void setJointRef(float q1, float q2, float q3);

  // Enable/Disable
  void setEnabled(bool enable);

  // Payload
  void setPayloadMass(float mass);

private:
  ArmMotor &m1_;
  ArmMotor &m2_;
  ArmMotor &m3_;
  Config cfg_;

  bool enabled_ = false;

  // Gravity Compensation
  void calculateGravityComp(float q1, float q2, float q3, float &t1, float &t2,
                            float &t3);

  // Precalculated Gravity Terms
  float G1_, G2_, G3_;
  float G_payload_factor_1_, G_payload_factor_2_, G_payload_factor_3_;
  float current_payload_mass_ = 0.0f;
};

} // namespace arm
} // namespace modules
