#include "ArmMotor.hpp"
#include <algorithm>

namespace modules {
namespace arm {

static constexpr float DEG_TO_RAD = 3.14159265f / 180.0f;
static constexpr float RPM_TO_RADS = 2.0f * 3.14159265f / 60.0f;

ArmMotor::ArmMotor(const Config &cfg) : cfg_(cfg) {}

void ArmMotor::setEnabled(bool enable) {
  enabled_ = enable;
  if (!enable) {
    integral_err_ = 0;
  }
}

void ArmMotor::setTarget(float pos, float vel, float torque_ff) {
  target_pos_ = pos;
  target_vel_ = vel;
  target_tff_ = torque_ff;
}

void ArmMotor::setMitParams(float kp, float kd, float ki, float i_limit) {
  cfg_.kp = kp;
  cfg_.kd = kd;
  cfg_.ki = ki;
  cfg_.i_limit = i_limit;
}

float ArmMotor::getAngle() const {
  switch (cfg_.type) {
  case MotorType::DJI:
    return cfg_.dji_motor->getAngle();
  case MotorType::DM:
    return cfg_.dm_motor->getAngle();
  }
  return 0.0f;
}

float ArmMotor::getVelocity() const {
  switch (cfg_.type) {
  case MotorType::DJI:
    return cfg_.dji_motor->getVelocity();
  case MotorType::DM:
    return cfg_.dm_motor->getVelocity();
  }
  return 0.0f;
}

void ArmMotor::update(float dt) {
  if (!enabled_) {
    // Zero current or disable
    if (cfg_.type == MotorType::DJI)
      cfg_.dji_motor->setCurrent(0);
    else if (cfg_.type == MotorType::DM)
      cfg_.dm_motor->setMitCommand(0, 0, 0, 0, 0);
    return;
  }

  float current_pos = getAngle();
  float current_vel = getVelocity();

  // Integral calculation (common for all)
  // Error in Degree/s or Rad/s?
  // Usually Kp is Nm/rad.
  // Let's convert everything to Rad for internal calc if we use Kp in Nm/rad.
  // BUT, the old driver used Degree.
  // Old driver: T = Kp*(Pos_des - Pos_fdb)
  // If Kp is tuned for Degree, we use Degree.

  float pos_err = target_pos_ - current_pos; // Degree
  float vel_err = target_vel_ - current_vel; // Degree/s

  // Integrate
  if (cfg_.ki > 0) {
    integral_err_ += pos_err * dt;
    // Limit
    if (integral_err_ > cfg_.i_limit)
      integral_err_ = cfg_.i_limit;
    if (integral_err_ < -cfg_.i_limit)
      integral_err_ = -cfg_.i_limit;
  }

  float t_integral = integral_err_ * cfg_.ki;

  if (cfg_.type == MotorType::DJI) {
    // Calculate Software PID
    float torque =
        cfg_.kp * pos_err + cfg_.kd * vel_err + target_tff_ + t_integral;
    // Convert Torque to IQ
    cfg_.dji_motor->setCurrent(torque * cfg_.torque_to_iq);
  } else if (cfg_.type == MotorType::DM) {
    // DM expects Rad?
    // Check DMMotor implementation.
    // DMMotor::setMitCommand -> `pos` and `vel` are converted using range.
    // Usually DM expects Radians.
    float pos_rad = target_pos_ * DEG_TO_RAD;
    float vel_rad = target_vel_ * DEG_TO_RAD;

    // For integral term, we add it to torque_ff
    float torque_ff_total = target_tff_ + t_integral;

    // Kp, Kd need likely conversion if they were in Degree.
    // But usually we just pass them if we re-tune or if they are in standard
    // units.

    cfg_.dm_motor->setMitCommand(pos_rad, vel_rad, cfg_.kp, cfg_.kd,
                                 torque_ff_total);
  }
}
} // namespace arm
} // namespace modules
