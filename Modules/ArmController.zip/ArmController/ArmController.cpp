#include "ArmController.hpp"
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265f
#endif

static constexpr float DEG_TO_RAD = M_PI / 180.0f;

namespace modules {
namespace arm {

Controller::Controller(ArmMotor &m1, ArmMotor &m2, ArmMotor &m3,
                       const Config &cfg)
    : m1_(m1), m2_(m2), m3_(m3), cfg_(cfg) {
  // Precalculate Gravity Coefficients
  // G3 = m3 * g * lc3
  G3_ = cfg_.m3 * cfg_.g * cfg_.lc3;

  // G2 = (m2 * lc2 + m3 * l2) * g
  G2_ = (cfg_.m2 * cfg_.lc2 + cfg_.m3 * cfg_.l2) * cfg_.g;

  // G1 = (m1 * lc1 + m2 * l1 + m3 * l1) * g
  G1_ = (cfg_.m1 * cfg_.lc1 + cfg_.m2 * cfg_.l1 + cfg_.m3 * cfg_.l1) * cfg_.g;

  // Payload Factors (assuming payload at end of L3)
  G_payload_factor_3_ = cfg_.g * (cfg_.l3);
  G_payload_factor_2_ = cfg_.g * cfg_.l2;
  G_payload_factor_1_ = cfg_.g * cfg_.l1;
}

void Controller::init() { setEnabled(false); }

void Controller::setEnabled(bool enable) {
  enabled_ = enable;
  m1_.setEnabled(enable);
  m2_.setEnabled(enable);
  m3_.setEnabled(enable);
}

void Controller::setPayloadMass(float mass) { current_payload_mass_ = mass; }

void Controller::setJointRef(float q1, float q2, float q3) {
  // Clamp limits
  if (q1 > cfg_.q1_max)
    q1 = cfg_.q1_max;
  if (q1 < cfg_.q1_min)
    q1 = cfg_.q1_min;
  if (q2 > cfg_.q2_max)
    q2 = cfg_.q2_max;
  if (q2 < cfg_.q2_min)
    q2 = cfg_.q2_min;
  if (q3 > cfg_.q3_max)
    q3 = cfg_.q3_max;
  if (q3 < cfg_.q3_min)
    q3 = cfg_.q3_min;

  float t1, t2, t3;
  // Calculate Gravity Comp Torque (Nm)
  calculateGravityComp(q1 * DEG_TO_RAD, q2 * DEG_TO_RAD, q3 * DEG_TO_RAD, t1,
                       t2, t3);

  // Apply Gear Ratios: Motor Torque = Joint Torque / Reduction Ratio
  float mt1 = t1 / cfg_.reduction_1;
  float mt2 = t2 / cfg_.reduction_2;
  float mt3 = t3 / cfg_.reduction_3;

  m1_.setTarget(q1, 0, mt1);
  m2_.setTarget(q2, 0, mt2);
  m3_.setTarget(q3, 0, mt3);
}

void Controller::update(float dt) {
  // Update motors
  m1_.update(dt);
  m2_.update(dt);
  m3_.update(dt);
}

void Controller::calculateGravityComp(float q1, float q2, float q3, float &tau1,
                                      float &tau2, float &tau3) {
  float c1 = cosf(q1);
  float c12 = cosf(q1 + q2);
  float c123 = cosf(q1 + q2 + q3);

  // Eff Gravity Terms
  float G3_eff = G3_ + current_payload_mass_ * G_payload_factor_3_;
  float G2_eff = G2_ + current_payload_mass_ * G_payload_factor_2_;
  float G1_eff = G1_ + current_payload_mass_ * G_payload_factor_1_;

  // Joint 3
  tau3 = G3_eff * c123;

  // Joint 2
  float term2 = G2_eff * c12;
  tau2 = term2 + tau3;

  // Joint 1
  float term1 = G1_eff * c1;
  tau1 = term1 + tau2;
}

bool Controller::setTargetPosition(float x, float y, float z, float pitch) {
  // Placeholder IK
  return false;
}

} // namespace arm
} // namespace modules
